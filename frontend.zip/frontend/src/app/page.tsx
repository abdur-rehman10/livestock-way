import PostService from '../pages/PostService';

export default function Page() {
  return <PostService />;
}
