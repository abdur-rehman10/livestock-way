export function canProceedDirect(accepted) {
  return !!accepted;
}
